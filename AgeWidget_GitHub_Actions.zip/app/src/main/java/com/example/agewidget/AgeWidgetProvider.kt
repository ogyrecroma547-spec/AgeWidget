package com.example.agewidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.SystemClock
import android.widget.RemoteViews
import java.time.Duration
import java.time.LocalDateTime
import java.time.Period
import java.time.ZoneId
import java.time.ZonedDateTime

class AgeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val zone = ZoneId.systemDefault()
        val now = ZonedDateTime.now(zone)
        val birth = LocalDateTime.of(2004, 10, 27, 0, 0).atZone(zone)

        val period = Period.between(birth.toLocalDate(), now.toLocalDate())
        val years = period.years
        val months = period.months
        val days = period.days

        // Chronometer shows the time elapsed after the last completed whole day.
        val completedCalendarAge = birth.plusYears(years.toLong())
            .plusMonths(months.toLong())
            .plusDays(days.toLong())
        val subDayMillis = Duration.between(completedCalendarAge, now).toMillis()
            .coerceAtLeast(0L)
        val chronometerBase = SystemClock.elapsedRealtime() - subDayMillis

        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.age_widget)
            views.setTextViewText(R.id.years, "$years лет")
            views.setTextViewText(R.id.days, "$months мес. · $days дн.")
            views.setChronometer(R.id.seconds, chronometerBase, "%s", true)
            manager.updateAppWidget(id, views)
        }
    }
}
